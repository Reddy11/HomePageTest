package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class Driver {

    ChromeOptions chromeOptions;

    public Driver() {
        this.chromeOptions = buildChromeOptions();
    }

    private ChromeOptions buildChromeOptions(){
        ChromeOptions optionsChrome = new ChromeOptions();
        optionsChrome.addArguments("start-maximized");
        optionsChrome.addArguments("lang=pt-BR");
        optionsChrome.setAcceptInsecureCerts(true);
        return optionsChrome;
    }

    public WebDriver driver(ChromeOptions chromeOptions) {
        WebDriver driver = new ChromeDriver(chromeOptions);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
        return driver;
    }

    public WebDriver driver() {
        WebDriver driver = new ChromeDriver(this.chromeOptions);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
        return driver;
    }
}