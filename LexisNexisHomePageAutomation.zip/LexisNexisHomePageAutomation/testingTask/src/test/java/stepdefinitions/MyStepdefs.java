package stepdefinitions;
import action.HomePageActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.HomePageElements;
import selenium.Driver;
import util.PropertyLoader;

import java.time.Duration;

public class MyStepdefs {
    private WebDriver driver;

    private HomePageActions homePageActions;

    private void initialisePages() {
        homePageActions = new HomePageActions(this.driver);
    }

    @Given("I navigate to the web page")
    public void iNavigateToTheWebPage() {
        this.driver = new Driver().driver();
        initialisePages();
        driver.get(PropertyLoader.returnConfigValue("url.base"));
        homePageActions.acceptCookies();
    }

    @Then("I check {string} button is present and clickable")
    public void iCheckButtonIsPresentAndClicakble(String text) {
        homePageActions.checkElementVisibleAndClickable(text);
    }

    @Then("I click the {string} tab")
    public void iCheckTab(String tabName) {
        homePageActions.clickOnTab(tabName);
    }

    @And("I click the {string} tab option")
    public void iCheckTabOptionIsPresentAndClickable(String optionName) {
        homePageActions.clickTabOption(optionName);
    }

    @Then("I check {string} tab content is present and clickable")
    public void iCheckTabContentIsPresentAndClickable(String option) {
        homePageActions.checkTabElementVisibleAndClickable(option);
    }
}
