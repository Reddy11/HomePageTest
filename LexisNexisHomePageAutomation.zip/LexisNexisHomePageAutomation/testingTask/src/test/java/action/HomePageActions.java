package action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.HomePageElements;
import org.junit.Assert;

import java.time.Duration;

public class HomePageActions {

    WebDriver driver;

    HomePageElements homePageElements;

    public HomePageActions(WebDriver driver) {
        this.driver = driver;
        this.homePageElements = new HomePageElements(this.driver);
    }

    public void acceptCookies() {
        if(homePageElements.acceptCookies().isDisplayed()) {
            homePageElements.acceptCookies().click();
        }
    }

    public void checkElementVisibleAndClickable(String text) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            wait.until(ExpectedConditions.elementToBeClickable(homePageElements.findButtonByText(text)));
        } catch(Exception e) {
            Assert.fail("Element " +text+ "is not visible and or clickable");
        }
    }

    public void clickOnTab(String tabName) {
        homePageElements.homePageTab(tabName).click();

    }

    public void clickTabOption(String optionName) {
        homePageElements.findTabDropDownButtonByText(optionName).click();
    }

    public void checkTabElementVisibleAndClickable(String option) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            wait.until(ExpectedConditions.elementToBeClickable(homePageElements.findDropDownPageButton(option)));
        } catch(Exception e) {
            Assert.fail("Element " +option+ "is not visible and or clickable");
        }
    }
}
