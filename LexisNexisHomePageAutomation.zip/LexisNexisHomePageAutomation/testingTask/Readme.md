To run the test and generate the report:
mvn test verify -Dcucumber.options="--tags @BasicTest"


Report will be in 
* target/site/serenity/index.html
* target/site/serenity/serenity-summary.html
